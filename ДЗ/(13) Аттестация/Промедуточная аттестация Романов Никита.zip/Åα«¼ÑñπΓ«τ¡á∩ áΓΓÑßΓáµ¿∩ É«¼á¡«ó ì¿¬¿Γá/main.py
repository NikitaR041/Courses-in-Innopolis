'''
    Для работы с функциями пропишите команду print(Calculator.Rules.__doc__), для этого нужно импортировать директорию
'''
import Calculator.Arithmetic as A

print(A.div(500,2))



